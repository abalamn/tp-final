import sys
import sqlite3
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QMainWindow, QVBoxLayout, QPushButton, QLineEdit, QLabel, QComboBox, QFormLayout, QHeaderView, QMessageBox
from PyQt5.QtGui import QStandardItemModel, QStandardItem, QRegularExpressionValidator
from PyQt5.QtCore import QRegularExpression
import hashlib
import re

class LoginWindow(QtWidgets.QWidget):
    def __init__(self, gastosdelmes_app):
        super().__init__()
        self.gastosdelmes_app = gastosdelmes_app
        self.setWindowTitle("Iniciar Sesión")
        self.setGeometry(100, 100, 300, 150)

        self.layout = QVBoxLayout()
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Nombre de usuario")
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Contraseña")
        self.password_input.setEchoMode(QLineEdit.Password)

        self.login_button = QPushButton("Iniciar Sesión")
        self.login_button.clicked.connect(self.login)

        self.register_button = QPushButton("Registrar")
        self.register_button.clicked.connect(self.open_register_window)

        self.layout.addWidget(self.username_input)
        self.layout.addWidget(self.password_input)
        self.layout.addWidget(self.login_button)
        self.layout.addWidget(self.register_button)
        self.setLayout(self.layout)

    def login(self):
        username = self.username_input.text()
        password = self.password_input.text()
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        with sqlite3.connect('finanzas.db') as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Users WHERE username = ? AND password = ?", (username, hashed_password))
            if cursor.fetchone():
                self.gastosdelmes_app.show()  # Mostrar la aplicación de gastos
                self.close()
            else:
                QMessageBox.warning(self, "Error", "Usuario o contraseña incorrectos.")

    def open_register_window(self):
        self.register_window = RegisterWindow()
        self.register_window.show()


class RegisterWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Registrar")
        self.setGeometry(100, 100, 300, 200)

        self.layout = QVBoxLayout()
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Nombre de usuario")
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Contraseña")
        self.password_input.setEchoMode(QLineEdit.Password)

        self.register_button = QPushButton("Registrar")
        self.register_button.clicked.connect(self.register)

        self.layout.addWidget(self.username_input)
        self.layout.addWidget(self.password_input)
        self.layout.addWidget(self.register_button)
        self.setLayout(self.layout)

    def register(self):
        username = self.username_input.text()
        password = self.password_input.text()

        if not username or not password:
            QMessageBox.warning(self, "Error", "Por favor, completa todos los campos.")
            return

        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        with sqlite3.connect('finanzas.db') as conn:
            cursor = conn.cursor()
            try:
                cursor.execute("INSERT INTO Users (username, password) VALUES (?, ?)", (username, hashed_password))
                conn.commit()
                QMessageBox.information(self, "Registro", "Registro exitoso.")
                self.close()
            except sqlite3.IntegrityError:
                QMessageBox.warning(self, "Error", "El usuario ya existe.")


class DateLineEdit(QLineEdit):
    def __init__(self):
        super().__init__()
        self.setMaxLength(10)  # Limitar a 10 caracteres (DD/MM/YYYY)
        self.textChanged.connect(self.format_date)

    def format_date(self, text):
        # Quitar caracteres no numéricos
        cleaned_text = re.sub(r'\D', '', text)

        # Formatear la fecha con barras
        if len(cleaned_text) >= 2:
            cleaned_text = cleaned_text[:2] + '/' + cleaned_text[2:]
        if len(cleaned_text) >= 5:
            cleaned_text = cleaned_text[:5] + '/' + cleaned_text[5:]

        self.setText(cleaned_text)
        self.setCursorPosition(len(cleaned_text))  # Mantener el cursor al final


class GastosDelMesApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gastos Personales del Mes")
        self.setGeometry(100, 100, 800, 600)

        # Conectar a la base de datos
        self.conn = sqlite3.connect('finanzas.db')
        self.cursor = self.conn.cursor()

        # Crear tablas si no existen
        self.cursor.execute(''' 
        CREATE TABLE IF NOT EXISTS Users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
        ''')
        self.cursor.execute(''' 
        CREATE TABLE IF NOT EXISTS Transacciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo TEXT NOT NULL,
            monto REAL NOT NULL,
            fecha TEXT NOT NULL,
            descripcion TEXT
        )
        ''')
        self.conn.commit()

        # Estilo de la aplicación
        self.setStyleSheet(""" 
            QMainWindow {
                background-color: #f0f0f0;
            }
            QLabel {
                font-size: 16px;
                font-weight: bold;
                color: #333;
            }
            QLineEdit, QComboBox {
                padding: 10px;
                font-size: 14px;
                border: 2px solid #007BFF;
                border-radius: 5px;
            }
            QPushButton {
                padding: 10px;
                font-size: 16px;
                border: 2px solid #007BFF;
                border-radius: 5px;
                background-color: transparent;
                color: #007BFF;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
            QPushButton:pressed {
                background-color: #d0d0d0;
            }
            QTableView {
                border: 1px solid #ccc;
                border-radius: 5px;
                background-color: #fff;
            }
        """)

        # Layout principal
        self.main_layout = QVBoxLayout()

        # Formulario para agregar transacciones
        self.form_layout = QFormLayout()

        self.tipo_input = QComboBox()
        self.tipo_input.addItems(["Ingreso", "Gasto"])

        self.monto_input = QLineEdit()
        self.monto_input.setPlaceholderText("Monto")

        # Validator para el campo de monto
        monto_regex = QRegularExpression(r"^\d*\.?\d*$")  # Permitir solo números y un punto decimal
        monto_validator = QRegularExpressionValidator(monto_regex)
        self.monto_input.setValidator(monto_validator)

        self.fecha_input = DateLineEdit()  # Usar el nuevo QLineEdit para fecha
        self.fecha_input.setPlaceholderText("Fecha (DD/MM/YYYY)")

        self.descripcion_input = QLineEdit()
        self.descripcion_input.setPlaceholderText("Descripción")

        self.form_layout.addRow(QLabel("Tipo"), self.tipo_input)
        self.form_layout.addRow(QLabel("Monto"), self.monto_input)
        self.form_layout.addRow(QLabel("Fecha"), self.fecha_input)
        self.form_layout.addRow(QLabel("Descripción"), self.descripcion_input)

        self.add_button = QPushButton("Agregar Transacción")
        self.add_button.clicked.connect(self.agregar_transaccion)

        self.delete_button = QPushButton("Eliminar Transacción")
        self.delete_button.clicked.connect(self.eliminar_transaccion)

        self.calcular_button = QPushButton("Calcular Saldo")
        self.calcular_button.clicked.connect(self.calcular_saldo)

        self.ingreso_label = QLabel("Total Ingresos: $0")
        self.gasto_label = QLabel("Total Gastos: $0")
        self.total_label = QLabel("Saldo Total: $0")

        self.table_view = QtWidgets.QTableView()
        self.table_view.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        self.main_layout.addLayout(self.form_layout)
        self.main_layout.addWidget(self.add_button)
        self.main_layout.addWidget(self.delete_button)
        self.main_layout.addWidget(self.table_view)
        self.main_layout.addWidget(self.calcular_button)
        self.main_layout.addWidget(self.ingreso_label)
        self.main_layout.addWidget(self.gasto_label)
        self.main_layout.addWidget(self.total_label)

        container = QtWidgets.QWidget()
        container.setLayout(self.main_layout)
        self.setCentralWidget(container)

        self.cargar_transacciones()

    def cargar_transacciones(self):
        self.cursor.execute("SELECT id, tipo, monto, fecha, descripcion FROM Transacciones")
        rows = self.cursor.fetchall()

        model = QStandardItemModel(len(rows), 5)
        model.setHorizontalHeaderLabels(['ID', 'Tipo', 'Monto', 'Fecha', 'Descripción'])

        for row_num, row_data in enumerate(rows):
            for col_num, col_data in enumerate(row_data):
                item = QStandardItem(str(col_data))
                if col_num == 2:  # Formatear el monto
                    item.setText(f"${self.formatear_monto(col_data)}")  # Añadir el signo $ a la izquierda
                model.setItem(row_num, col_num, item)

        self.table_view.setModel(model)

    def formatear_monto(self, monto):
        return f"{monto:,.2f}".replace(',', '.')  # Usar punto como separador de miles y formato con 2 decimales

    def agregar_transaccion(self):
        try:
            tipo = self.tipo_input.currentText()
            monto = float(self.monto_input.text().replace('.', '').replace(',', '.'))  # Manejar el formato del monto
            fecha = self.fecha_input.text()
            descripcion = self.descripcion_input.text()

            # Validar la fecha
            if not re.match(r"^(\d{2}/\d{2}/\d{4})$", fecha):
                QMessageBox.warning(self, "Error", "Por favor, introduce una fecha válida en el formato DD/MM/YYYY.")
                return

            self.cursor.execute('''INSERT INTO Transacciones (tipo, monto, fecha, descripcion) VALUES (?, ?, ?, ?)''', (tipo, monto, fecha, descripcion))
            self.conn.commit()
            self.cargar_transacciones()
            self.monto_input.clear()
            self.fecha_input.clear()
            self.descripcion_input.clear()
        except ValueError:
            QMessageBox.warning(self, "Error", "Por favor, introduce un monto válido.")

    def eliminar_transaccion(self):
        selected_index = self.table_view.currentIndex()
        if selected_index.isValid():
            transaction_id = self.table_view.model().item(selected_index.row(), 0).text()
            self.cursor.execute("DELETE FROM Transacciones WHERE id = ?", (transaction_id,))
            self.conn.commit()
            self.cargar_transacciones()
        else:
            QMessageBox.warning(self, "Error", "Por favor, selecciona una transacción para eliminar.")

    def calcular_saldo(self):
        self.cursor.execute("SELECT SUM(monto) FROM Transacciones WHERE tipo = 'Ingreso'")
        total_ingresos = self.cursor.fetchone()[0] or 0

        self.cursor.execute("SELECT SUM(monto) FROM Transacciones WHERE tipo = 'Gasto'")
        total_gastos = self.cursor.fetchone()[0] or 0

        saldo_total = total_ingresos - total_gastos

        self.ingreso_label.setText(f"Total Ingresos: ${self.formatear_monto(total_ingresos)}")
        self.gasto_label.setText(f"Total Gastos: ${self.formatear_monto(total_gastos)}")
        self.total_label.setText(f"Saldo Total: ${self.formatear_monto(saldo_total)}")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)

    gastosdelmes_app = GastosDelMesApp()
    login_window = LoginWindow(gastosdelmes_app)
    login_window.show()

    sys.exit(app.exec_())
