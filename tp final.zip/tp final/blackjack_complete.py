import sys
import random
from PyQt5.QtWidgets import (
    QApplication, QWidget, QPushButton, QLabel, QVBoxLayout,
    QHBoxLayout, QLineEdit, QMessageBox, QTextEdit
)

class Blackjack(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.reset_game()

    def initUI(self):
        self.setWindowTitle('Blackjack - Un Solo Jugador')
        self.setGeometry(100, 100, 800, 600)

        self.layout = QVBoxLayout()
        self.setStyleSheet("background-color: #2E2E2E; color: white; font-size: 18px;")

        self.label = QLabel('Bienvenido a Blackjack')
        self.layout.addWidget(self.label)

        self.balance_label = QLabel(f'Balance: $100')
        self.layout.addWidget(self.balance_label)

        self.bet_input = QLineEdit()
        self.bet_input.setPlaceholderText('Introduce apuesta')
        self.layout.addWidget(self.bet_input)

        self.player_label = QLabel('Tu Mano: ')
        self.layout.addWidget(self.player_label)

        self.dealer_label = QLabel('Mano del Crupier: ')
        self.layout.addWidget(self.dealer_label)

        self.history_text = QTextEdit()
        self.history_text.setReadOnly(True)
        self.layout.addWidget(self.history_text)

        button_layout = QHBoxLayout()

        self.hit_button = QPushButton('Pedir Carta')
        self.hit_button.clicked.connect(self.hit_player)
        button_layout.addWidget(self.hit_button)

        self.stand_button = QPushButton('Plantarse')
        self.stand_button.clicked.connect(self.stand_player)
        button_layout.addWidget(self.stand_button)

        self.start_button = QPushButton('Iniciar Juego')
        self.start_button.clicked.connect(self.start_game)
        self.layout.addWidget(self.start_button)

        self.reset_button = QPushButton('Reiniciar')
        self.reset_button.clicked.connect(self.reset_game)
        self.layout.addWidget(self.reset_button)

        self.layout.addLayout(button_layout)
        self.setLayout(self.layout)
        self.show()

    def create_deck(self):
        deck = [value for value in range(1, 14)] * 4  # 1-13 (as, 2-10, j, q, k)
        random.shuffle(deck)
        return deck

    def reset_game(self):
        self.deck = self.create_deck()
        self.player_hand = []
        self.dealer_hand = []
        self.balance = 100
        self.current_bet = 0
        self.game_active = False

        self.balance_label.setText(f'Balance: ${self.balance}')
        self.bet_input.clear()
        self.update_labels()
        self.hit_button.setEnabled(False)
        self.stand_button.setEnabled(False)

    def start_game(self):
        try:
            bet = int(self.bet_input.text())
            if bet <= 0 or bet > self.balance:
                raise ValueError("Apuesta inválida")

            self.current_bet = bet
            self.balance -= self.current_bet

            self.label.setText('¡Juego comenzado!')

            self.player_hand = [self.deck.pop(), self.deck.pop()]
            self.dealer_hand = [self.deck.pop(), self.deck.pop()]
            self.game_active = True
            self.update_labels()
            self.hit_button.setEnabled(True)
            self.stand_button.setEnabled(True)
        except ValueError:
            QMessageBox.warning(self, "Error", "Por favor, introduce una apuesta válida.")

    def hit_player(self):
        if self.game_active:
            self.player_hand.append(self.deck.pop())
            self.update_labels()
            if self.calculate_hand_value(self.player_hand) > 21:
                self.label.setText('Te pasaste de 21! Fin del juego.')
                self.balance -= self.current_bet
                self.game_active = False
                self.history_text.append(f'Perdiste ${self.current_bet}.')
                self.check_game_over()
            else:
                self.label.setText('Pides otra carta.')

    def stand_player(self):
        self.label.setText('Te has plantado.')
        if self.game_active:
            self.dealer_play()

    def dealer_play(self):
        while self.calculate_hand_value(self.dealer_hand) < 17:
            self.dealer_hand.append(self.deck.pop())
        self.update_labels()
        self.determine_winner()

    def update_labels(self):
        player_value = self.calculate_hand_value(self.player_hand)
        dealer_value = self.calculate_hand_value(self.dealer_hand)

        self.player_label.setText(f'Tu Mano: {self.player_hand} (Valor: {player_value})')
        self.dealer_label.setText(f'Mano del Crupier: {self.dealer_hand} (Valor: {dealer_value})')

    def calculate_hand_value(self, hand):
        value = sum(hand)
        if value > 21 and 1 in hand:
            value -= 10
        return value

    def determine_winner(self):
        player_value = self.calculate_hand_value(self.player_hand)
        dealer_value = self.calculate_hand_value(self.dealer_hand)

        if player_value == 21 and len(self.player_hand) == 2:
            self.label.setText('¡Blackjack! Ganaste 1.5 veces la apuesta.')
            self.balance += int(self.current_bet * 2.5)
            self.history_text.append(f'Ganaste ${int(self.current_bet * 2.5)}.')
        elif dealer_value > 21 or player_value > dealer_value:
            self.label.setText(f'¡Ganaste! Has ganado ${self.current_bet * 2}.')
            self.balance += self.current_bet * 2
            self.history_text.append(f'Ganaste ${self.current_bet * 2}.')
        elif player_value < dealer_value:
            self.label.setText('El crupier gana.')
            self.history_text.append(f'Perdiste ${self.current_bet}.')
        else:
            self.label.setText('Empate.')
            self.balance += self.current_bet  # Devuelven la apuesta
            self.history_text.append(f'Empate. Recuperaste ${self.current_bet}.')

        self.balance_label.setText(f'Balance: ${self.balance}')
        self.hit_button.setEnabled(False)
        self.stand_button.setEnabled(False)
        self.check_game_over()

    def check_game_over(self):
        if self.balance <= 0:
            QMessageBox.warning(self, "Fin del juego", "¡Has perdido todo tu dinero! ¡Juego terminado!")
            self.reset_game()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Blackjack()
    sys.exit(app.exec_())
